package com.cart3r.tttranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.Paint
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.roundToInt

class ScreenTranslateService : Service() {

    companion object {
        const val ACTION_START = "com.cart3r.tttranslator.START"
        const val ACTION_STOP = "com.cart3r.tttranslator.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "tt_translation"
        private const val NOTIFICATION_ID = 401
        private const val DEFAULT_FRAME_INTERVAL_MS = 1500L
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var overlay: WindowManager? = null
    private var handlerThread: HandlerThread? = null
    private var worker: Handler? = null
    private var recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var translator: Translator? = null
    private val busy = AtomicBoolean(false)
    private val translatedCache = mutableMapOf<String, String>()
    private val overlayViews = mutableListOf<TextView>()
    private var selectionView: SelectionView? = null
    private var selectionParams: WindowManager.LayoutParams? = null
    private var selectedRect = Rect()
    private var frameIntervalMs = DEFAULT_FRAME_INTERVAL_MS
    private var screenWidth = 0
    private var screenHeight = 0
    private var density = 1f
    private var lastFrameAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> {
                if (projection != null) stopCapture()
                startForegroundCompat()
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = getResultData(intent) ?: run { stopSelf(); return START_NOT_STICKY }
                startProjection(resultCode, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun getResultData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)

    private fun startForegroundCompat() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "TT Screen Translator", NotificationManager.IMPORTANCE_LOW
            ))
        }
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("TT Screen Translator ativo")
            .setContentText("Captura autorizada • tradução local")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        density = metrics.density
        frameIntervalMs = getSharedPreferences("tt_settings", MODE_PRIVATE)
            .getLong("interval_ms", DEFAULT_FRAME_INTERVAL_MS).coerceIn(500L, 5000L)
        val prefs = getSharedPreferences("tt_settings", MODE_PRIVATE)
        val left = prefs.getInt("area_left", (screenWidth * 0.08f).toInt())
        val top = prefs.getInt("area_top", (screenHeight * 0.12f).toInt())
        val right = prefs.getInt("area_right", (screenWidth * 0.92f).toInt())
        val bottom = prefs.getInt("area_bottom", (screenHeight * 0.88f).toInt())
        selectedRect = Rect(left, top, right, bottom)

        handlerThread = HandlerThread("TT-OCR").also { it.start() }
        worker = Handler(handlerThread!!.looper)

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.PORTUGUESE)
            .build()
        translator = Translation.getClient(options)

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = projectionManager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, worker)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "TT-Screen-Capture", screenWidth, screenHeight,
            metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, worker
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()
            if (now - lastFrameAt < frameIntervalMs || !busy.compareAndSet(false, true)) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastFrameAt = now
            val image = reader.acquireLatestImage()
            if (image == null) { busy.set(false); return@setOnImageAvailableListener }
            val bitmap = try { imageToBitmap(image) } catch (_: Exception) { null } finally { image.close() }
            if (bitmap == null) { busy.set(false); return@setOnImageAvailableListener }
            recognize(bitmap)
        }, worker)

        downloadTranslationModel()
        overlay = getSystemService(WINDOW_SERVICE) as WindowManager
        worker?.post { showSelectionWindow() }
    }

    private fun downloadTranslationModel() {
        val model = translator ?: return
        model.downloadModelIfNeeded()
            .addOnSuccessListener { /* modelo EN→PT pronto; execução local */ }
            .addOnFailureListener { stopCapture() }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }


    private fun recognize(bitmap: Bitmap) {
        val crop = Rect(
            selectedRect.left.coerceIn(0, bitmap.width - 1),
            selectedRect.top.coerceIn(0, bitmap.height - 1),
            selectedRect.right.coerceIn(1, bitmap.width),
            selectedRect.bottom.coerceIn(1, bitmap.height)
        )
        if (crop.width() < 20 || crop.height() < 20) {
            bitmap.recycle(); busy.set(false); return
        }
        val croppedBitmap = Bitmap.createBitmap(bitmap, crop.left, crop.top, crop.width(), crop.height())
        bitmap.recycle()
        val input = InputImage.fromBitmap(croppedBitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val candidates = result.textBlocks.flatMap { it.lines }
                    .filter { it.text.any(Char::isLetter) && it.boundingBox != null }
                    .take(35)
                if (candidates.isEmpty()) {
                    clearOverlay()
                    croppedBitmap.recycle()
                    busy.set(false)
                    return@addOnSuccessListener
                }

                val translated = java.util.Collections.synchronizedList(
                    mutableListOf<Pair<Rect, String>>()
                )
                val remaining = java.util.concurrent.atomic.AtomicInteger(candidates.size)
                val finished = AtomicBoolean(false)

                fun completeOne() {
                    if (remaining.decrementAndGet() == 0 && finished.compareAndSet(false, true)) {
                        showTranslations(translated.toList())
                        croppedBitmap.recycle()
                        busy.set(false)
                    }
                }

                candidates.forEach { line ->
                    val bounds = line.boundingBox ?: run { completeOne(); return@forEach }
                    val original = line.text.trim()
                    val cached = translatedCache[original]
                    if (cached != null) {
                        translated.add(Rect(bounds).apply { offset(crop.left, crop.top) } to cached)
                        completeOne()
                    } else {
                        val activeTranslator = translator
                        if (activeTranslator == null) {
                            completeOne()
                        } else {
                            activeTranslator.translate(original)
                                .addOnSuccessListener { text ->
                                    translatedCache[original] = text
                                    translated.add(Rect(bounds).apply { offset(crop.left, crop.top) } to text)
                                    completeOne()
                                }
                                .addOnFailureListener { completeOne() }
                        }
                    }
                }
            }
            .addOnFailureListener {
                croppedBitmap.recycle()
                busy.set(false)
            }
    }

    private fun showTranslations(items: List<Pair<Rect, String>>) {
        worker?.post {
            clearOverlay()
            val wm = overlay ?: return@post
            items.forEach { (rect, text) ->
                if (text.isBlank()) return@forEach
                val view = TextView(this).apply {
                    this.text = text
                    textSize = 12f
                    setTextColor(android.graphics.Color.WHITE)
                    setBackgroundColor(0xEE101010.toInt())
                    setPadding(4, 2, 4, 2)
                    maxLines = 4
                }
                val params = WindowManager.LayoutParams(
                    max(48, rect.width()),
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    if (Build.VERSION.SDK_INT >= 26)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = rect.left.coerceAtLeast(0)
                    y = rect.top.coerceAtLeast(0)
                }
                try {
                    wm.addView(view, params)
                    overlayViews.add(view)
                } catch (_: Exception) { }
            }
        }
    }

    private fun showSelectionWindow() {
        val wm = overlay ?: return
        if (selectionView != null) return
        val view = SelectionView(this)
        val params = WindowManager.LayoutParams(
            selectedRect.width().coerceAtLeast((160 * density).toInt()),
            selectedRect.height().coerceAtLeast((120 * density).toInt()),
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = selectedRect.left
            y = selectedRect.top
        }
        view.onBoundsChanged = { x, y, w, h ->
            params.x = x; params.y = y; params.width = w; params.height = h
            try { wm.updateViewLayout(view, params) } catch (_: Exception) { }
            selectedRect = Rect(x, y, x + w, y + h)
            getSharedPreferences("tt_settings", MODE_PRIVATE).edit()
                .putInt("area_left", selectedRect.left).putInt("area_top", selectedRect.top)
                .putInt("area_right", selectedRect.right).putInt("area_bottom", selectedRect.bottom).apply()
        }
        try {
            wm.addView(view, params)
            selectionView = view
            selectionParams = params
        } catch (_: Exception) { }
    }

    private inner class SelectionView(context: Context) : View(context) {
        private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(40, 220, 110)
            style = Paint.Style.STROKE
            strokeWidth = 3f * density
        }
        private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(40, 220, 110)
            style = Paint.Style.FILL
        }
        private var downRawX = 0f
        private var downRawY = 0f
        private var startX = 0
        private var startY = 0
        private var startW = 0
        private var startH = 0
        private var resizing = false
        var onBoundsChanged: ((Int, Int, Int, Int) -> Unit)? = null
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val inset = border.strokeWidth
            canvas.drawRect(inset, inset, width - inset, height - inset, border)
            val r = 18f * density
            canvas.drawCircle(width - r, height - r, r, handle)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val lp = selectionParams ?: return false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX; downRawY = event.rawY
                    startX = lp.x; startY = lp.y; startW = lp.width; startH = lp.height
                    resizing = event.x >= width - 42f * density && event.y >= height - 42f * density
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    val x: Int; val y: Int; val w: Int; val h: Int
                    if (resizing) {
                        x = startX; y = startY
                        w = (startW + dx).coerceAtLeast((120 * density).toInt())
                        h = (startH + dy).coerceAtLeast((90 * density).toInt())
                    } else {
                        w = startW; h = startH
                        x = (startX + dx).coerceIn(0, (screenWidth - w).coerceAtLeast(0))
                        y = (startY + dy).coerceIn(0, (screenHeight - h).coerceAtLeast(0))
                    }
                    onBoundsChanged?.invoke(x, y, w, h)
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }
    }

    private fun clearOverlay() {
        val wm = overlay ?: return
        overlayViews.toList().forEach { view ->
            try { wm.removeView(view) } catch (_: Exception) { }
        }
        overlayViews.clear()
    }

    private fun stopCapture() {
        clearOverlay()
        val wm = overlay
        selectionView?.let { try { wm?.removeView(it) } catch (_: Exception) { } }
        selectionView = null
        selectionParams = null
        imageReader?.setOnImageAvailableListener(null, null)
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        translator?.close()
        translator = null
        recognizer.close()
        handlerThread?.quitSafely()
        handlerThread = null
        worker = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        clearOverlay()
        selectionView?.let { try { overlay?.removeView(it) } catch (_: Exception) { } }
        selectionView = null
        selectionParams = null
        virtualDisplay?.release()
        imageReader?.close()
        translator?.close()
        recognizer.close()
        handlerThread?.quitSafely()
        super.onDestroy()
    }
}
