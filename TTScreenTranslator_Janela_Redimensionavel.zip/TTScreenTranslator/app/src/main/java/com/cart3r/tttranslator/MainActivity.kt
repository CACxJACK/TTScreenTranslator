package com.cart3r.tttranslator

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.runtime.DisposableEffect
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val service = Intent(this, ScreenTranslateService::class.java).apply {
                    action = ScreenTranslateService.ACTION_START
                    putExtra(ScreenTranslateService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenTranslateService.EXTRA_RESULT_DATA, result.data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
                else startService(service)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TranslatorHome(
            onStart = { beginCapture() },
            onStop = { startService(Intent(this, ScreenTranslateService::class.java).setAction(ScreenTranslateService.ACTION_STOP)) },
            overlayAllowed = { Settings.canDrawOverlays(this) },
            requestOverlay = {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        ) }
    }

    private fun beginCapture() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }
}

@Composable
private fun TranslatorHome(
    onStart: () -> Unit,
    onStop: () -> Unit,
    overlayAllowed: () -> Boolean,
    requestOverlay: () -> Unit
) {
    var running by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val settings = remember { context.getSharedPreferences("tt_settings", android.content.Context.MODE_PRIVATE) }
    var intervalSeconds by remember { mutableFloatStateOf(settings.getLong("interval_ms", 1500L) / 1000f) }
    var overlayGranted by remember { mutableStateOf(overlayAllowed()) }
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) overlayGranted = overlayAllowed()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val black = Color(0xFF080808)
    val red = Color(0xFFFF3030)
    MaterialTheme(colorScheme = darkColorScheme(
        primary = red, background = black, surface = Color(0xFF171717)
    )) {
        Column(
            Modifier.fillMaxSize().background(black).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("TT SCREEN TRANSLATOR", color = Color.White, style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black)
            Text("ENGLISH  →  PORTUGUÊS  •  OFFLINE", color = Color.White)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF191111))) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MODO REPLACE", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Uma janela verde aparece sobre a tela. Arraste o centro para mover e use o canto inferior direito para redimensionar a região de leitura.", color = Color.White)
                    Text("A região selecionada é usada como limite do OCR.", color = Color.White)
                }
            }
            Text("INTERVALO DE ATUALIZAÇÃO: ${"%.1f".format(intervalSeconds)} s", color = Color.White, fontWeight = FontWeight.Bold)
            Slider(
                value = intervalSeconds,
                onValueChange = { value ->
                    intervalSeconds = value
                    settings.edit().putLong("interval_ms", (value * 1000).toLong()).apply()
                },
                valueRange = 0.5f..5f,
                steps = 8,
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = red, inactiveTrackColor = Color.DarkGray)
            )
            Text("A janela de seleção captura apenas a região delimitada. Enquanto ela estiver visível, toques dentro dela são usados para mover/redimensionar a janela.", color = Color.White, style = MaterialTheme.typography.bodySmall)
            Text(
                if (overlayGranted) "✓ Permissão de sobreposição concedida"
                else "A permissão 'Exibir sobre outros apps' é necessária.",
                color = if (overlayGranted) Color(0xFF7CDE91) else Color(0xFFFFC36B)
            )
            if (!overlayGranted) {
                Button(onClick = requestOverlay, modifier = Modifier.fillMaxWidth()) {
                    Text("CONCEDER SOBREPOSIÇÃO", color = Color.White)
                }
            }
            Button(
                onClick = { onStart(); running = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = red),
                enabled = !running && overlayGranted
            ) { Text("INICIAR TRADUÇÃO", color = Color.White, fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { onStop(); running = false },
                modifier = Modifier.fillMaxWidth()
            ) { Text("PARAR TRADUÇÃO", color = Color.White) }
            Text(
                "A primeira utilização pode exigir internet para baixar o modelo EN→PT. " +
                    "Depois do download, a tradução funciona no dispositivo. A captura exige confirmação do Android.",
                color = Color.Gray,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.weight(1f))
            Text("CART3R ENGINE • v1.1.0", color = Color.White)
        }
    }
}
