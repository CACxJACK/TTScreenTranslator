# TT Screen Translator — CART3R

Android nativo em Kotlin: captura autorizada da tela, OCR local com ML Kit e tradução EN→PT com modelo baixado sob demanda.

## Requisitos
- Android Studio atualizado
- JDK 17
- Android SDK 35
- Um dispositivo Android 8.0 (API 26) ou superior

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `TTScreenTranslator` no Android Studio.
3. Aguarde o Gradle Sync.
4. Conecte um aparelho Android ou inicie um emulador.
5. Execute `app`.

Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O APK debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Linha de comando:
```bash
./gradlew assembleDebug
```
No Windows:
```bat
gradlew.bat assembleDebug
```

## Primeiro uso
1. Abra o TT Screen Translator.
2. Conceda “Exibir sobre outros apps”.
3. Toque em “Iniciar tradução”.
4. Confirme a captura na janela de consentimento do Android.
5. Aguarde o modelo de tradução EN→PT ser baixado na primeira utilização.
6. Para encerrar, volte ao app e toque em “Parar tradução” ou encerre a notificação.

## Como funciona
- OCR: modelo latino empacotado no app.
- Tradução: ML Kit Translation; o modelo de idioma é baixado sob demanda e depois roda no dispositivo.
- Captura: MediaProjection em serviço de primeiro plano.
- Overlay: máscaras escuras com texto português sobre as regiões reconhecidas.

## Limitações conhecidas desta versão inicial
- O modo REPLACE é uma substituição visual aproximada: a máscara cobre a região do texto e pode cobrir partes do fundo, ícones ou elementos próximos. Não reconstrói fundos complexos.
- Alguns apps bloqueiam captura por `FLAG_SECURE`; o Android pode mostrar tela preta.
- O sistema pode exigir autorização novamente em cada nova sessão de captura.
- Esta versão usa OCR latino e está otimizada para texto inglês legível; texto pequeno, curvo, animado ou de baixo contraste pode falhar.
- O modelo de tradução precisa ser baixado uma vez com internet. A tradução posterior funciona offline.
- A captura da tela inteira e as janelas flutuantes podem variar entre fabricantes e versões Android.
- Para produção, implementar cache LRU, deduplicação de linhas, adaptação de rotação, controle de memória, testes em Android 14/15/16 e uma estratégia para evitar que o próprio overlay seja reconhecido no próximo quadro.

## Privacidade
A captura é iniciada somente após o consentimento explícito do Android. O código não envia frames ou textos para um servidor próprio. O download inicial do modelo ML Kit requer conectividade.


## Compilar sem computador (GitHub Actions)
Este projeto inclui `.github/workflows/build-apk.yml` para compilar o APK em nuvem.

1. No navegador do Android, crie uma conta em https://github.com/ e um repositório novo chamado `TTScreenTranslator`.
2. Extraia este ZIP usando um gerenciador de arquivos que consiga abrir ZIP.
3. Envie o conteúdo da pasta para o repositório pelo site do GitHub. Inclua também a pasta oculta `.github/workflows` e o arquivo `build-apk.yml`. Se o site móvel não permitir enviar a pasta oculta, use a opção "Add file > Create new file" e crie `.github/workflows/build-apk.yml`, colando o conteúdo do workflow.
4. Abra a aba **Actions** do repositório. Se solicitado, habilite workflows.
5. Selecione **Build Android APK** e toque em **Run workflow**. Também compila automaticamente a cada push para `main`.
6. Quando terminar com um visto verde, abra a execução e baixe o artefato `TTScreenTranslator-debug-apk`.
7. Extraia o APK do ZIP do artefato e toque nele para instalar. Talvez seja necessário permitir instalação desse navegador/gerenciador de arquivos nas configurações do Android.

O APK gerado é de depuração e não está assinado para distribuição na Play Store. Para publicar, será necessário configurar uma chave de assinatura privada e um build release.
